# [EN] Installation Guide

* Double click on `Old Turkic.dmg` file to mount the disk image. 
* Launch `Keyboard Installer.app`, then drag & drop the `Old Turkic.bundle` file on application window.
* Select `Install for current user` option.
* Log out/in to your user account.
* That's it. Go to `Keyboard` preference pane in `System Settings` to select the keyboard layout.

Refer to `Layout-Düzen.pdf` file to see how the keys are located, and how the modifier keys work.

# [TR] Yükleme Kılavuzu

* `Old Turkic.dmg` disk kalıbına çift tıklayın.
* `Keyboard Installer.app` uygulamasını çalıştırın ve paket içerisindeki `Old Turkic.bundle` dosyasını uygulama penceresine sürükleyip bırakın.
* `Install for current user` seçeneğine tıklayın.
* Kullanıcı hesabınızdan çıkış yapın ve tekrar girin. 
* Bu kadar! Artık `Sistem Tercihleri` -> `Klavye` bölümünden `Eski Türkçe` dizilimini etkinleştirebilirsiniz.

Dizilime göz gezdirmek ve kaydırma düğmelerinin nice çalıştığına bakmak için paket içerisindeki `Layout-Düzen.pdf` dosyasına bakabilirsiniz.

Emir SARI <bitigchi@me.com>, 2019
