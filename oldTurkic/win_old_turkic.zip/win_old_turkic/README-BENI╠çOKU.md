# [EN] Installation Guide

* Double click on `setup.exe`.
* Run the installer.
* That's it! Go to System Settings to add the new keyboard layout to your language bar.

In case you are unable to view the tamgas within Windows, make sure that you are running at least Windows 7/8 with all the updates, and install the `Orkun` font included in this package.

If you need to see the layout schema, refer to the `Layout-Düzen.pdf` file.

# [TR] Yükleme Kılavuzu

* `setup.exe` dosyasına çift tıklayın.
* Yükleyiciyi çalıştırın.
* Bu kadar. Artık Sistem Ayarları'ndan bu klavye dizilimini dil çubuğuna ekleyebilirsiniz.

Eğer damgaları görüntüleyemiyorsanız en azından bütün güncellemeleri yapılmış bir Windows 7/8 kullandığınızdan emin olun. Paket içerisinde bulunan `Orkun` yazıtipini çift tıklayarak kurun.

Dizilim şemasını görmek isterseniz, paket içerisindeki `Layout-Düzen.pdf` dosyasına bakabilirsiniz.

Emir SARI <bitigchi@me.com>, 2019
