# [EN] Installation Guide

Merge the `usr` folder with the `usr` folder on root. You will need root access privileges.

Following files are modified/merged:

## Modified Files

* `usr/share/X11/xkb/rules/base.extras.xml`
* `usr/share/X11/xkb/rules/evdev.extras.xml`
* `usr/share/X11/xkb/symbols/tr`

Log out/in, then you will be able to select `Old Turkic` layout from layout settings. If you cannot see the tamgas, you will need to install an Old Turkic font; `Orkun` font is included in this package for your convenience.

If you are unable to find the layout in the list, you might need to enable "Include less-common used layouts in the selection list" (or similar, wording may differ) setting in your Keyboard preferences.

# [TR] Yükleme Kılavuzu

Paket içerisindeki `usr` dizinini sistem `usr` dizini ile birleştirin. Bu işlem için kök dizin erişimine gereksiniminiz olacak.

## Değiştirilen Dosyalar

* `usr/share/X11/xkb/rules/base.extras.xml`
* `usr/share/X11/xkb/rules/evdev.extras.xml`
* `usr/share/X11/xkb/symbols/tr`

Kullanıcı hesabınızdan çıkış yapıp tekrar girdikten sonra klavye dizilimi ayarlarından `Old Turkic` dizilimini seçebileceksiniz. Eğer hâlâ damgaları görüntüleyemiyorsanız, bir Eski Türkçe yazıtipi yüklemeniz gerekmektedir; `Orkun` yazıtipini bu pakette bulabilirsiniz.

Eğer dizilimler listesinde `Old Turkic` girdisini göremiyorsanız dağıtımınıza bağlı olarak değişecek şekilde "Az kullanılan klavye dizilimlerini göster" seçeneğini etkinleştirmeniz gerekebilir.

Emir SARI <bitigchi@me.com>, 2020
