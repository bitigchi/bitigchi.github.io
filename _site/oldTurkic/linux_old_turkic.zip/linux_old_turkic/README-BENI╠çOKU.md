# [EN] Installation Guide

Merge the `usr` folder with the `usr` folder on root. You will need root access privileges.

Following files are modified/merged:

## Added Files

* `usr/share/iso-flag-png/ot.png`
* `usr/share/X11/xkb/symbols/ot`

## Modified Files

* `usr/share/X11/xkb/rules/base.lst`
* `usr/share/X11/xkb/rules/base.xml`
* `usr/share/X11/xkb/rules/evdev.lst`
* `usr/share/X11/xkb/rules/evdev.xml`

Log out/in, then you will be able to select "Old Turkic" layout from layout settings. If you cannot see the tamgas, you will need to install an Old Turkic font; `Orkun` font is included in this package for your convenience.

# [TR] Yükleme Kılavuzu

Paket içerisindeki `usr` dizinini sistem `usr` dizini ile birleştirin. Bu işlem için kök dizin erişimine gereksiniminiz olacak.

## Eklenen Dosyalar

* `usr/share/iso-flag-png/ot.png`
* `usr/share/X11/xkb/symbols/ot`

## Değiştirilen Dosyalar

* `usr/share/X11/xkb/rules/base.lst`
* `usr/share/X11/xkb/rules/base.xml`
* `usr/share/X11/xkb/rules/evdev.lst`
* `usr/share/X11/xkb/rules/evdev.xml`

Kullanıcı hesabınızdan çıkış yapıp tekrar girdikten sonra klavye dizilimi ayarlarından "Old Turkic" dizilimini seçebileceksiniz. Eğer hâlâ damgaları görüntüleyemiyorsanız, bir Eski Türkçe yazıtipi yüklemeniz gerekmektedir; `Orkun` yazıtipini bu pakette bulabilirsiniz.

Emir SARI <bitigchi@me.com>, 2019
